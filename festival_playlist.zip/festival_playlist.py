"""
Programa: festival_playlist.py
Descripcion: Sistema de gestion inteligente de playlist para un festival de musica
utilizando arreglos paralelos (listas en Python) para almacenar y analizar canciones.
"""

def pedir_entero_positivo(mensaje: str) -> int:
    """Solicita y valida un numero entero mayor a cero."""
    while True:
        try:
            valor = int(input(mensaje))
            if valor > 0:
                return valor
            print("Error: El valor debe ser mayor a 0.")
        except ValueError:
            print("Error: Ingrese un numero entero valido.")


def pedir_float_positivo(mensaje: str) -> float:
    """Solicita y valida un numero decimal mayor a cero."""
    while True:
        try:
            valor = float(input(mensaje))
            if valor > 0.0:
                return valor
            print("Error: La duracion debe ser mayor a 0 minutos.")
        except ValueError:
            print("Error: Ingrese un numero decimal valido.")


def pedir_popularidad(mensaje: str) -> int:
    """Solicita y valida que la popularidad este entre 1 y 100."""
    while True:
        try:
            valor = int(input(mensaje))
            if 1 <= valor <= 100:
                return valor
            print("Error: La popularidad debe estar en el rango de 1 a 100.")
        except ValueError:
            print("Error: Ingrese un numero entero valido.")


def agregar_canciones(nombres, artistas, duraciones, popularidades):
    """Permite registrar N canciones en las listas paralelas."""
    print("\n--- AGREGAR CANCIONES A LA PLAYLIST ---")
    cantidad = pedir_entero_positivo("Cuantas canciones desea agregar?: ")

    for i in range(cantidad):
        print(f"\nDatos de la cancion #{len(nombres) + 1}:")
        nombre = input("Nombre de la cancion : ").strip()
        while not nombre:
            print("Error: El nombre no puede estar vacio.")
            nombre = input("Nombre de la cancion : ").strip()

        artista = input("Artista o agrupacion : ").strip()
        while not artista:
            print("Error: El artista no puede estar vacio.")
            artista = input("Artista o agrupacion : ").strip()

        duracion = pedir_float_positivo("Duracion en minutos (ej. 3.5) : ")
        popularidad = pedir_popularidad("Popularidad (1 a 100) : ")

        nombres.append(nombre)
        artistas.append(artista)
        duraciones.append(duracion)
        popularidades.append(popularidad)

    print(f"\nExito: Se agregaron {cantidad} cancion(es) a la playlist.")


def mostrar_tabla_canciones(indices, nombres, artistas, duraciones, popularidades, titulo="LISTADO DE CANCIONES"):
    """Imprime una tabla formateada de canciones segun una lista de indices."""
    print("\n" + "=" * 70)
    print(f"               {titulo}               ")
    print("=" * 70)
    print(f"{'#':<4}{'Titulo':<26}{'Artista':<22}{'Duracion':<10}{'Popularidad':<10}")
    print("-" * 70)

    for idx in indices:
        print(f"{idx + 1:<4}{nombres[idx]:<26}{artistas[idx]:<22}{duraciones[idx]:>6.2f} min{popularidades[idx]:>8}/100")

    print("-" * 70)


def ver_reportes(nombres, artistas, duraciones, popularidades):
    """Muestra estadisticas generales y canciones destacadas de la playlist."""
    if not nombres:
        print("\nAviso: La playlist esta vacia. Agregue canciones primero.")
        return

    total_canciones = len(nombres)
    duracion_total = sum(duraciones)
    promedio_pop = sum(popularidades) / total_canciones

    # Encontrar indices de cancion mas y menos popular
    max_pop = max(popularidades)
    min_pop = min(popularidades)
    idx_max = popularidades.index(max_pop)
    idx_min = popularidades.index(min_pop)

    print("\n" + "=" * 55)
    print("             REPORTE GENERAL DE LA PLAYLIST            ")
    print("=" * 55)
    print(f"Numero total de canciones   : {total_canciones}")
    print(f"Duracion total de playlist  : {duracion_total:.2f} minutos")
    print(f"Promedio de popularidad     : {promedio_pop:.2f} / 100")
    print("-" * 55)
    print(f"Cancion mas popular         : '{nombres[idx_max]}' de {artistas[idx_max]} ({max_pop}/100)")
    print(f"Cancion menos popular       : '{nombres[idx_min]}' de {artistas[idx_min]} ({min_pop}/100)")
    print("=" * 55)

    todos_los_indices = list(range(total_canciones))
    mostrar_tabla_canciones(todos_los_indices, nombres, artistas, duraciones, popularidades, "CANCIONES REGISTRADAS")


def buscar_canciones(nombres, artistas, duraciones, popularidades):
    """Permite filtrar canciones por artista o por rango de popularidad."""
    if not nombres:
        print("\nAviso: La playlist esta vacia. Agregue canciones primero.")
        return

    print("\n--- CRITERIO DE BUSQUEDA ---")
    print("1. Buscar por artista")
    print("2. Buscar por rango de popularidad")
    sub_opcion = input("Seleccione criterio (1 o 2): ").strip()

    if sub_opcion == "1":
        termino = input("Ingrese el nombre del artista a buscar: ").strip().lower()
        coincidencias = [i for i, art in enumerate(artistas) if termino in art.lower()]

        if coincidencias:
            mostrar_tabla_canciones(coincidencias, nombres, artistas, duraciones, popularidades, f"RESULTADOS PARA '{termino.upper()}'")
        else:
            print(f"\nNo se encontraron canciones del artista '{termino}'.")

    elif sub_opcion == "2":
        print("Ingrese el rango de popularidad:")
        pop_min = pedir_popularidad("Popularidad minima (1-100): ")
        pop_max = pedir_popularidad("Popularidad maxima (1-100): ")

        if pop_min > pop_max:
            pop_min, pop_max = pop_max, pop_min

        coincidencias = [i for i, pop in enumerate(popularidades) if pop_min <= pop <= pop_max]

        if coincidencias:
            mostrar_tabla_canciones(coincidencias, nombres, artistas, duraciones, popularidades, f"POPULARIDAD ENTRE {pop_min} Y {pop_max}")
        else:
            print(f"\nNo se encontraron canciones en el rango [{pop_min}, {pop_max}].")
    else:
        print("Error: Opcion de busqueda no valida.")


def playlist_recomendada(nombres, artistas, duraciones, popularidades):
    """Bonus creativo: genera y muestra canciones con popularidad superior al promedio."""
    if not nombres:
        print("\nAviso: La playlist esta vacia. Agregue canciones primero.")
        return

    promedio_pop = sum(popularidades) / len(popularidades)
    indices_recomendados = [i for i, pop in enumerate(popularidades) if pop > promedio_pop]

    print("\n" + "=" * 55)
    print("                 PLAYLIST RECOMENDADA                  ")
    print("=" * 55)
    print(f"Criterio: Popularidad superior al promedio ({promedio_pop:.2f}/100)")
    print(f"Canciones recomendadas: {len(indices_recomendados)} de {len(nombres)}")

    if indices_recomendados:
        mostrar_tabla_canciones(indices_recomendados, nombres, artistas, duraciones, popularidades, "TRACKS DESTACADOS")
    else:
        print("No hay canciones por encima del promedio estricto.")


def main():
    # Arreglos paralelos para almacenar los datos
    nombres = []
    artistas = []
    duraciones = []
    popularidades = []

    print("==================================================")
    print("   SISTEMA DE PLAYLIST PARA FESTIVAL DE MUSICA    ")
    print("==================================================")

    while True:
        print("\n--- MENU PRINCIPAL ---")
        print("1. Agregar canciones")
        print("2. Ver reportes")
        print("3. Buscar canciones")
        print("4. Playlist recomendada")
        print("5. Salir")

        opcion = input("Seleccione una opcion (1-5): ").strip()

        if opcion == "1":
            agregar_canciones(nombres, artistas, duraciones, popularidades)
        elif opcion == "2":
            ver_reportes(nombres, artistas, duraciones, popularidades)
        elif opcion == "3":
            buscar_canciones(nombres, artistas, duraciones, popularidades)
        elif opcion == "4":
            playlist_recomendada(nombres, artistas, duraciones, popularidades)
        elif opcion == "5":
            print("\nGracias por usar el gestor de playlist del festival. Hasta pronto.\n")
            break
        else:
            print("Error: Opcion no valida. Seleccione un numero del 1 al 5.")


if __name__ == "__main__":
    main()
